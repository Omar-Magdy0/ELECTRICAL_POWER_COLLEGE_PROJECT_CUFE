#include "core.h"

_settings settings;




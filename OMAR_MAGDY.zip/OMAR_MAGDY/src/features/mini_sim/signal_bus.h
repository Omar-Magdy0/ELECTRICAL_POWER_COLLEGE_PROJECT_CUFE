#pragma once

class signal_bus{
  
};